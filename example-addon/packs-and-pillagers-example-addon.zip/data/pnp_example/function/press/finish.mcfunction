function pnp_example:press/out with entity @s item.components."minecraft:custom_data".pj
data remove entity @s item.components."minecraft:custom_data".pj
function pnp:api/machine/progress {p:0}
playsound minecraft:block.piston.contract block @a[distance=..24] ~ ~ ~ 0.6 0.7
particle minecraft:block{block_state:"minecraft:gravel"} ~ ~0.1 ~ 0.25 0.05 0.25 0 12
