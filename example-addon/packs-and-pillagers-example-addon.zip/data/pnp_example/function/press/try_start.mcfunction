execute unless function pnp:api/machine/take run return 0
data modify entity @s item.components."minecraft:custom_data".pj set value {t:0}
data modify entity @s item.components."minecraft:custom_data".pj.c set from storage pnp:machine io.c
function pnp:api/machine/progress {p:1}
playsound minecraft:block.piston.extend block @a[distance=..24] ~ ~ ~ 0.5 0.8
