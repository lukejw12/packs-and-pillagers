execute store result score #pq pnp_ex.tmp run function pnp:api/machine/count
title @a[distance=..16] actionbar {translate:"pnp_example.press.waiting",fallback:"Crushing Press: %s waiting.",with:[{score:{name:"#pq",objective:"pnp_ex.tmp"}}]}
