$scoreboard players set #pn pnp_ex.tmp $(min)
$execute unless score #pn pnp_ex.tmp matches $(max) run function pnp_example:press/roll_range {min:$(min),max:$(max)}
$data modify storage pnp_example:press e.c set value "$(c)"
function pnp_example:press/emit_loop
