execute if score #pn pnp_ex.tmp matches ..0 run return 0
function pnp:api/machine/emit with storage pnp_example:press e
scoreboard players remove #pn pnp_ex.tmp 1
function pnp_example:press/emit_loop
