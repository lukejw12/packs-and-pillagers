$execute store result score #pn pnp_ex.tmp run random value $(min)..$(max)
