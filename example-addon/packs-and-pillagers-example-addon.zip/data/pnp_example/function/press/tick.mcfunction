execute unless data entity @s item.components."minecraft:custom_data".pj run function pnp_example:press/try_start
execute unless data entity @s item.components."minecraft:custom_data".pj run return run function pnp:api/machine/progress {p:0}
execute store result score #pt pnp_ex.tmp run data get entity @s item.components."minecraft:custom_data".pj.t
scoreboard players add #pt pnp_ex.tmp 1
execute store result entity @s item.components."minecraft:custom_data".pj.t int 1 run scoreboard players get #pt pnp_ex.tmp
execute if score #pt pnp_ex.tmp matches 4.. run return run function pnp_example:press/finish
execute store result storage pnp_example:press pg.p int 25 run scoreboard players get #pt pnp_ex.tmp
function pnp:api/machine/progress with storage pnp_example:press pg
