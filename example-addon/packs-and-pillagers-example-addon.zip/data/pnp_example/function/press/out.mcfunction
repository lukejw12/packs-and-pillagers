$data modify storage pnp_example:press o set from storage pnp_example:press out.$(c)
function pnp_example:press/roll with storage pnp_example:press o
