data modify storage pnp:cards defs.golden_carrot set value {id:"golden_carrot",name:"Golden Carrot",kind:"food",food:6,meal:6,heal:4,sell:12,give:"minecraft:golden_carrot",gn:1,desc:"Food: 6. A carrot dipped in gold.",l1:"Food: 6. A carrot",l2:"dipped in gold.",atlas:"minecraft:items",sprite:"item/golden_carrot"}
function pnp:api/add_card {id:"golden_carrot",category:"c2"}
data modify storage pnp:cards recipes append value {r:1001,in:{villager:1,carrot:1,gold_ingot:1},n:3,time:80,use:["carrot","gold_ingot"],out:["golden_carrot"],il:[{c:"villager",n:1},{c:"carrot",n:1},{c:"gold_ingot",n:1}]}
data modify storage pnp:cards free.r1001 set value 1b
scoreboard objectives add pnp_ex.tmp dummy
data modify storage pnp:cards defs.gravel set value {id:"gravel",name:"Gravel",kind:"res",sell:2,desc:"Loose stone. Sift it and you might find something.",l1:"Loose stone. Sift it",l2:"and you might find",l3:"something.",atlas:"minecraft:blocks",sprite:"block/gravel"}
function pnp:api/add_card {id:"gravel",category:"c1"}
data modify storage pnp:cards defs.raw_iron set value {id:"raw_iron",name:"Raw Iron",kind:"res",sell:3,desc:"Smelt it into an Iron Ingot.",l1:"Smelt it into an",l2:"Iron Ingot.",atlas:"minecraft:items",sprite:"item/raw_iron"}
function pnp:api/add_card {id:"raw_iron",category:"c1"}
data modify storage pnp:cards defs.raw_gold set value {id:"raw_gold",name:"Raw Gold",kind:"res",sell:4,desc:"Smelt it into a Gold Ingot.",l1:"Smelt it into a",l2:"Gold Ingot.",atlas:"minecraft:items",sprite:"item/raw_gold"}
function pnp:api/add_card {id:"raw_gold",category:"c1"}
data modify storage pnp:cards defs.raw_copper set value {id:"raw_copper",name:"Raw Copper",kind:"res",sell:2,desc:"Smelt it into a Copper Ingot.",l1:"Smelt it into a",l2:"Copper Ingot.",atlas:"minecraft:items",sprite:"item/raw_copper"}
function pnp:api/add_card {id:"raw_copper",category:"c1"}
data modify storage pnp:cards defs.crushing_press set value {id:"crushing_press",name:"Crushing Press",kind:"struct",sell:20,desc:"Crushes cobblestone into gravel and ores into 2 to 4 raw metal. Drop cards on it or pipe them in.",l1:"Crushes cobblestone",l2:"into gravel and ores",l3:"into 2-4 raw metal.",l4:"Drop or pipe cards in.",atlas:"minecraft:blocks",sprite:"block/piston_side"}
function pnp:api/add_card {id:"crushing_press",category:"c4"}
data modify storage pnp:cards defs.sift set value {id:"sift",name:"Sift",kind:"tool",sell:6,desc:"Villager + Sift + Gravel shakes out sticks, raw metal, or something rare.",l1:"Villager + Sift +",l2:"Gravel shakes out",l3:"sticks, raw metal,",l4:"or something rare.",atlas:"minecraft:blocks",sprite:"block/scaffolding_top"}
function pnp:api/add_card {id:"sift",category:"c6"}
data modify storage pnp:cards machines.crushing_press set value {in:1,out:1,storage:16,accepts:["cobblestone","iron_ore","gold_ore","copper_ore"],on_tick:"pnp_example:press/tick",on_use:"pnp_example:press/use"}
data modify storage pnp_example:press out set value {cobblestone:{c:"gravel",min:1,max:1},iron_ore:{c:"raw_iron",min:2,max:4},gold_ore:{c:"raw_gold",min:2,max:4},copper_ore:{c:"raw_copper",min:2,max:4}}
data modify storage pnp:cards smelt.raw_iron set value "iron_ingot"
data modify storage pnp:cards smelt.raw_gold set value "gold_ingot"
data modify storage pnp:cards smelt.raw_copper set value "copper_ingot"
data modify storage pnp:cards pools.sift set value {t:100,e:[{c:"nothing",w:28},{c:"cobblestone",w:22},{c:"stick",w:16},{c:"raw_iron",w:12},{c:"raw_copper",w:10},{c:"raw_gold",w:6},{c:"coal",w:3},{c:"emerald",w:2},{c:"diamond",w:1}]}
data modify storage pnp:cards recipes append value {r:1002,in:{villager:1,crafting_table:1,iron_ingot:3,cobblestone:3},n:8,time:120,use:["iron_ingot","iron_ingot","iron_ingot","cobblestone","cobblestone","cobblestone"],out:["crushing_press"],il:[{c:"villager",n:1},{c:"crafting_table",n:1},{c:"iron_ingot",n:3},{c:"cobblestone",n:3}]}
data modify storage pnp:cards recipes append value {r:1003,in:{villager:1,crafting_table:1,stick:3,planks:1},n:6,time:60,use:["stick","stick","stick","planks"],out:["sift"],il:[{c:"villager",n:1},{c:"crafting_table",n:1},{c:"stick",n:3},{c:"planks",n:1}]}
data modify storage pnp:cards recipes append value {r:1004,in:{furnace:1,raw_iron:1,coal:1},n:3,time:100,use:["raw_iron","coal"],out:["iron_ingot"],il:[{c:"furnace",n:1},{c:"raw_iron",n:1},{c:"coal",n:1}]}
data modify storage pnp:cards recipes append value {r:1005,in:{furnace:1,raw_gold:1,coal:1},n:3,time:100,use:["raw_gold","coal"],out:["gold_ingot"],il:[{c:"furnace",n:1},{c:"raw_gold",n:1},{c:"coal",n:1}]}
data modify storage pnp:cards recipes append value {r:1006,in:{furnace:1,raw_copper:1,coal:1},n:3,time:100,use:["raw_copper","coal"],out:["copper_ingot"],il:[{c:"furnace",n:1},{c:"raw_copper",n:1},{c:"coal",n:1}]}
data modify storage pnp:cards recipes append value {r:1007,in:{villager:1,sift:1,gravel:1},n:3,time:60,use:["gravel"],out:["@sift"],il:[{c:"villager",n:1},{c:"sift",n:1},{c:"gravel",n:1}]}
data modify storage pnp:cards free.r1002 set value 1b
data modify storage pnp:cards free.r1003 set value 1b
data modify storage pnp:cards free.r1004 set value 1b
data modify storage pnp:cards free.r1005 set value 1b
data modify storage pnp:cards free.r1006 set value 1b
data modify storage pnp:cards free.r1007 set value 1b
